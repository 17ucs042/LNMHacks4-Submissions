package com.appsaga.findingyou;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class FileReport extends AppCompatActivity {

    private DatabaseReference mDatabase;

    Button fileReport;
    EditText fullName,contact,dob,guardianName,
            fullAddress,lostDate,features;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_file_report);

        fileReport=findViewById(R.id.fileReport);
        fullName=findViewById(R.id.full_name);
        contact=findViewById(R.id.contact);
        dob=findViewById(R.id.dob);
        guardianName=findViewById(R.id.guardian_name);
        fullAddress=findViewById(R.id.full_address);
        lostDate=findViewById(R.id.lost_date);
        features=findViewById(R.id.features);

        mDatabase = FirebaseDatabase.getInstance().getReference();

        fileReport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String FullName = fullName.getText().toString();
                String Contact = contact.getText().toString();
                String DOB = dob.getText().toString();
                String GuardianName = guardianName.getText().toString();
                String FullAddress = fullAddress.getText().toString();
                String LostDate = lostDate.getText().toString();
                String Features = features.getText().toString();

                Report report = new Report(FullName,Contact,DOB,GuardianName,FullAddress,LostDate,Features);
                addReportToDatabase(report);
            }
        });
    }

    void addReportToDatabase(Report report)
    {
        mDatabase.child("reports").child(110+(int)(Math.random()*1000)+"").setValue(report).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {

                Toast.makeText(FileReport.this,"Report Filed",Toast.LENGTH_LONG).show();
                finish();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {

                Toast.makeText(FileReport.this,"Some error occurred",Toast.LENGTH_LONG).show();
            }
        });

    }
}
