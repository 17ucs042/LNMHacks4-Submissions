package com.appsaga.findingyou;

public class Report {

    String fullName;
    String contact;
    String dob;
    String guardianName;
    String fullAddress;
    String lostDate;
    String uniqueAddress;

    public Report(String fullName, String contact, String dob, String guardianName, String fullAddress, String lostDate, String uniqueAddress) {
        this.fullName = fullName;
        this.contact = contact;
        this.dob = dob;
        this.guardianName = guardianName;
        this.fullAddress = fullAddress;
        this.lostDate = lostDate;
        this.uniqueAddress = uniqueAddress;
    }

    public Report() {

    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getGuardianName() {
        return guardianName;
    }

    public void setGuardianName(String guardianName) {
        this.guardianName = guardianName;
    }

    public String getFullAddress() {
        return fullAddress;
    }

    public void setFullAddress(String fullAddress) {
        this.fullAddress = fullAddress;
    }

    public String getLostDate() {
        return lostDate;
    }

    public void setLostDate(String lostDate) {
        this.lostDate = lostDate;
    }

    public String getUniqueAddress() {
        return uniqueAddress;
    }

    public void setUniqueAddress(String uniqueAddress) {
        this.uniqueAddress = uniqueAddress;
    }
}
