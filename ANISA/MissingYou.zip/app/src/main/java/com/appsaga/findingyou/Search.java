package com.appsaga.findingyou;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class Search extends AppCompatActivity {

    EditText searchText;
    ImageView search;
    DatabaseReference databaseReference;

    ArrayList<Report> peopleList = new ArrayList<>();
    ListView reportsList;
    ReportsAdapter reportsAdapter;
    Button findByImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        searchText=findViewById(R.id.search);
        search=findViewById(R.id.search_icon);
        reportsList=findViewById(R.id.reports_list);
        findByImage=findViewById(R.id.find_by_image);

        databaseReference= FirebaseDatabase.getInstance().getReference();

        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                getData(searchText.getText().toString());
            }
        });

        findByImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(Search.this,FindSimilarFaceActivity.class));
            }
        });
    }

    void getData(final String name)
    {
        ValueEventListener reportListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // Get Post object and use the values to update the UI

                for(DataSnapshot ds:dataSnapshot.getChildren())
                {
                    Report report = ds.getValue(Report.class);

                    Log.d("Test",report.getContact()+"");
                    if(report!=null)
                    {
                        if(report.getFullName().toLowerCase().equalsIgnoreCase(name.toLowerCase())||
                                report.getFullName().toLowerCase().contains(name.toLowerCase()))
                        {
                            peopleList.add(report);
                        }
                    }
                }

                if(peopleList.size()!=0)
                {
                    reportsAdapter=new ReportsAdapter(Search.this,peopleList);
                    reportsList.setAdapter(reportsAdapter);
                }
                else
                {
                    Toast.makeText(Search.this,"No such person found",Toast.LENGTH_LONG).show();
                }
                // ...
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Getting Post failed, log a message
                Log.w("Test", "loadPost:onCancelled", databaseError.toException());
                // ...
            }
        };

        databaseReference.child("reports").addValueEventListener(reportListener);
        Log.d("refe",databaseReference+"");
    }
}
