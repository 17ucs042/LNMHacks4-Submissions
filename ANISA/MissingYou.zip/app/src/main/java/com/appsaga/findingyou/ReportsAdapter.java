package com.appsaga.findingyou;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import java.util.ArrayList;

public class ReportsAdapter extends ArrayAdapter<Report> {

    public ReportsAdapter(@NonNull Context context, ArrayList<Report> report) {
        super(context, 0, report);
    }

    @Override
    public View getView(final int position, View convertView, final ViewGroup parent) {

        View listItemView = convertView;

        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.report_view, parent, false);
        }

        Report report = getItem(position);

        TextView name = listItemView.findViewById(R.id.full_name);
        TextView contact = listItemView.findViewById(R.id.contact);
        TextView dob = listItemView.findViewById(R.id.dob);

        name.setText("Full Name: "+report.getFullName());
        contact.setText("Contact Number: "+report.getContact());
        dob.setText("DOB: "+report.getDob());

        return listItemView;
    }
}
